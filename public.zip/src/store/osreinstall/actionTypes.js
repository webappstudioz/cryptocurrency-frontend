export const GET_OS = "GET_OS"
export const GET_CP = "GET_CP"
export const Get_SERVICE_NAME = "Get_SERVICE_NAME"
export const Get_PARTITION_MODE = "Get_PARTITION_MODE"



