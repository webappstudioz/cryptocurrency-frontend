export const GET_WIDGETS = "get_widgets"
export const WIDGETS_FETCHED = "widgets_fetched"
export const ADD_CURRENCY = "add_currency"