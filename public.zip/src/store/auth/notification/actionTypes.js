export const NOTIFICATION_UPDATE = "notification_update"
export const NOTIFICATION_UPDATED = "notification_updated"
export const REMOVE_NOTIFICATIONS = "remove_notifications"