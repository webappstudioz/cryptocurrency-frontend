export const ADD_SEARCH = "add_search"
export const SEARCH_KEY = "search_key"
export const REMOVE_SEARCH = "remove_search"
