export const USER_UPDATE = "user_update"
export const USER_UPDATED = "user_updated"
export const NOT_UPDATE = "not_update"

