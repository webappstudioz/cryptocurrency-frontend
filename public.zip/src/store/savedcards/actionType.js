export const GET_CARDS = "get_cards"
export const CARDS_FETCHED = "cards_fetched"
export const REMOVE_CARDS = "remove_cards"