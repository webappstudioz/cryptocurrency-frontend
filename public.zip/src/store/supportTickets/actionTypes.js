export const GET_SUPPORT_TICKETS = "get_support_tickets"
export const REMOVE_SUPPORT_TICKETS = "remove_support_tickets"