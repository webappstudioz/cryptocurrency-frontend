export const PRODUCT = "product";
export const OVERVIEW = "overview";
export const USAGE = "usage";