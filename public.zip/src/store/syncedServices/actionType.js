export const FETCHED_SERVICES = "fetched_services"
export const REMOVE_FETCHED_SERVICES = "remove_fetched_services"