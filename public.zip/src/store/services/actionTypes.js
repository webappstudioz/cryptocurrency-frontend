export const GET_SERVICES = "get_services"
export const REMOVE_SERVICES = "remove_services"
export const SYNCSERVICESILENT = "sync_service_silent"
export const SERVICESYNCED = "service_synced"
export const ALLSERVICESSYNC = "all_service_sync"
export const ALLSERVICESSYNCSUCCESS = "all_service_sync_success"

