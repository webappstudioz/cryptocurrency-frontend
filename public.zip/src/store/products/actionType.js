export const INSTANT_PRODUCTS = "instant_products";
export const INSTANT_SALE = "instant_sale";
export const INSTANT_NEWEST = "instant_newest";
export const INSTANT_LOW_TO_HOGH = "instant_low_to_high";
export const INSTANT_HIGH_TO_LOW = "instant_high_to_low";

export const CUSTOM_PRODUCTS = "custom_products";
export const CUSTOM_SALE = "custom_sale";
export const CUSTOM_NEWEST = "custom_newest";
export const CUSTOM_LOW_TO_HOGH = "custom_low_to_high";
export const CUSTOM_HIGH_TO_LOW = "custom_high_to_low";
export const ADD_CURRENCY = "add_currency"
export const REMOVE_PRODUCTS = "remove_products";
