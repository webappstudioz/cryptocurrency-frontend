export const GET_LIST_OS = "fetch_osinstall_list"
export const OS_LIST_FETCHED = "osinstall_list_fetched"
